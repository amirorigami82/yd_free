<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>��ʾ��Ϣ -  ��ֽѧԺ -  ��ֽ��ѧ - ZHEZHIXUEYUAN.COM</title>

<meta name="keywords" content="" />
<meta name="description" content=",��ֽѧԺ" />
<meta name="generator" content="Discuz! X3.4" />
<meta name="author" content="Discuz! Team and Comsenz UI Team" />
<meta name="copyright" content="2001-2021 Tencent Cloud." />
<meta name="MSSmartTagsPreventParsing" content="True" />
<meta http-equiv="MSThemeCompatible" content="Yes" />
<base href="https://www.zhezhixueyuan.com/" /><link rel="stylesheet" type="text/css" href="data/cache/style_13_common.css?KIM" /><link rel="stylesheet" type="text/css" href="data/cache/style_13_forum_attachment.css?KIM" /><script type="text/javascript">var STYLEID = '13', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = 'KIM', charset = 'gbk', discuz_uid = '137502', cookiepre = 'SgUf_2132_', cookiedomain = '', cookiepath = '/', showusercard = '1', attackevasive = '0', disallowfloat = 'newthread|reply', creditnotice = '1|��ֽ��|,7|����|,8|������|', defaultstyle = '', REPORTURL = 'aHR0cHM6Ly93d3cuemhlemhpeHVleXVhbi5jb20vZm9ydW0ucGhwP21vZD1hdHRhY2htZW50JmFpZD1OREU0TmpjMGZEQTRNVEExTURRNWZERTNOemc1TkRNd01EQjhNVE0zTlRBeWZERTNNVEk0TnprJTNE', SITEURL = 'https://www.zhezhixueyuan.com/', JSPATH = 'data/cache/', CSSPATH = 'data/cache/style_', DYNAMICURL = '';</script>
<script src="data/cache/common.js?KIM" type="text/javascript"></script>
<meta name="application-name" content="��ֽѧԺ" />
<meta name="msapplication-tooltip" content="��ֽѧԺ" />
<meta name="msapplication-task" content="name=��ҳ;action-uri=https://www.zhezhixueyuan.com/forum.php;icon-uri=https://www.zhezhixueyuan.com/static/image/common/bbs.ico" />
<meta name="msapplication-task" content="name=Ȧ��;action-uri=https://www.zhezhixueyuan.com/group.php;icon-uri=https://www.zhezhixueyuan.com/static/image/common/group.ico" /><meta name="msapplication-task" content="name=��԰;action-uri=https://www.zhezhixueyuan.com/home.php;icon-uri=https://www.zhezhixueyuan.com/static/image/common/home.ico" /><link rel="archives" title="��ֽѧԺ" href="https://www.zhezhixueyuan.com/archiver/" />
<script src="data/cache/forum.js?KIM" type="text/javascript"></script>
<script src="//sdk.51.la/js-sdk-pro.min.js" type="text/javascript"></script>
    <script>LA.init({id: "JUjYt0VBNA1ahvB1",ck: "JUjYt0VBNA1ahvB1"})</script>
</head>
<body id="nv_forum" class="pg_attachment" onkeydown="if(event.keyCode==27) return false;">
<div id="append_parent"></div><div id="ajaxwaitid"></div>
<div class="xi1 bm bm_c">
    ��ѡ�� <a href="https://www.zhezhixueyuan.com/forum.php?mobile=yes">�����ֻ���</a> <span class="xg1">|</span> <a href="">�������ʵ��԰�</a>
</div>
<div id="toptb" class="cl">
<div class="wp">
<div class="z"><a href="javascript:;"  onclick="setHomepage('https://www.zhezhixueyuan.com/');">[��Ϊ��ҳ]</a><a href="https://www.zhezhixueyuan.com/"  onclick="addFavorite(this.href, '��ֽѧԺ');return false;">[�ղر�վ]</a><a href="plugin.php?id=dev8133_integralpaypal" title="Paypal��ֵ֧�����"  style="color: red">[PayPal��ֵ]</a></div>
<div class="y">
<a id="switchblind" href="javascript:;" onclick="toggleBlind(this)" title="������������" class="switchblind"></a>
<a href="javascript:;" id="switchwidth" onclick="widthauto(this)" title="�л�������" class="switchwidth">�л�������</a>
<a id="sslct" href="javascript:;" onmouseover="delayShow(this, function() {showMenu({'ctrlid':'sslct','pos':'34!'})});">�л����</a></div>
</div>
</div>

<ul id="myprompt_menu" class="p_pop" style="display: none;">
<li><a href="home.php?mod=space&amp;do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news_0"></em>��Ϣ</a></li>
<li><a href="home.php?mod=follow&amp;do=follower"><em class="prompt_follower_0"></em>�·�˿</a></li>
<li class="ignore_noticeli"><a href="javascript:;" onclick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="�ݲ�����"><em class="ignore_notice"></em></a></li>
</ul>
<div id="sslct_menu" class="cl p_pop" style="display: none;">
<span class="sslct_btn" onclick="extstyle('')" title="Ĭ��"><i></i></span><span class="sslct_btn" onclick="extstyle('./template/mystyle/style/t2')" title="��"><i style='background:#429296'></i></span>
<span class="sslct_btn" onclick="extstyle('./template/mystyle/style/t1')" title="��"><i style='background:#BA350F'></i></span>
<span class="sslct_btn" onclick="extstyle('./template/mystyle/style/t4')" title="��"><i style='background:#9934B7'></i></span>
<span class="sslct_btn" onclick="extstyle('./template/mystyle/style/t3')" title="��"><i style='background:#FE9500'></i></span>
<span class="sslct_btn" onclick="extstyle('./template/mystyle/style/t5')" title="��"><i style='background:#0053B9'></i></span>
</div>
<ul id="myitem_menu" class="p_pop" style="display: none;">
<li><a href="forum.php?mod=guide&amp;view=my">����</a></li>
<li><a href="home.php?mod=space&amp;do=favorite&amp;view=me">�ղ�</a></li>
<li><a href="home.php?mod=space&amp;do=friend">����</a></li>
</ul>
<ul id="credit_menu" class="p_pop" style="display: none;">
<li><a href="home.php?mod=spacecp&amp;ac=plugin&amp;op=credit&amp;id=xiaomy_weixc:weixc">΢��֧��</a></li>
<li><a href="plugin.php?id=liangzai_mqypay">֧����֧��</a></li>
<li><a href="plugin.php?id=dev8133_integralpaypal">PayPal֧��</a></li>
</ul>
<div id="qmenu_menu" class="p_pop " style="display: none;">
<ul class="cl nav"><li><a href="home.php?mod=follow" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/follow_b.png) !important">�㲥</a></li>
<li><a href="home.php?mod=space&do=blog" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/blog_b.png) !important">��־</a></li>
<li><a href="home.php?mod=space&do=album" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/album_b.png) !important">���</a></li>
<li><a href="home.php?mod=space&do=doing" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/doing_b.png) !important">��¼</a></li>
<li><a href="home.php?mod=space&do=friend" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/friend_b.png) !important">����</a></li>
<li><a href="home.php?mod=magic" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/magic_b.png) !important">����</a></li>
<li><a href="home.php?mod=medal" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/medal_b.png) !important">ѫ��</a></li>
<li><a href="home.php?mod=space&do=favorite&view=me" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/favorite_b.png) !important">�ղ�</a></li>
<li><a href="home.php?mod=space&do=share" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/share_b.png) !important">����</a></li>
<li><a href="home.php?mod=space&do=wall" style="background-image:url(https://www.zhezhixueyuan.com/static/image/feed/wall_b.png) !important">���԰�</a></li>
</ul>
</div><div id="hd">
<div class="wp">
<div class="hdc cl"><h2><a href="./" title="��ֽѧԺ"></a></h2><div id="um">
<div class="avt y"><a href="home.php?mod=space&amp;uid=137502"><img src="https://www.zhezhixueyuan.com/uc_server/data/avatar/000/13/75/02_avatar_small.jpg" onerror="this.onerror=null;this.src='https://www.zhezhixueyuan.com/uc_server/images/noavatar_small.gif'" /></a></div>
<p>
<strong><a href="home.php?mod=space&amp;uid=137502" target="_blank" title="�����ҵĿռ�"></a></strong>
    		<span id="loginstatus">
    			<a id="loginstatusid" href="member.php?mod=switchstatus" title="�л�����״̬" onclick="ajaxget(this.href, 'loginstatus');return false;" class="xi2"></a>
    		</span>
<script>function showmyrepeats() {if(!$('myrepeats_menu')) {menu=document.createElement('div');menu.id='myrepeats_menu';menu.style.display='none';menu.className='p_pop';$('append_parent').appendChild(menu);ajaxget('plugin.php?id=myrepeats:switch&list=yes','myrepeats_menu','ajaxwaitid');}showMenu({'ctrlid':'myrepeats','duration':2});}</script><span class="pipe">|</span><a id="myrepeats" href="home.php?mod=spacecp&ac=plugin&id=myrepeats:memcp" class="showmenu cur1" onmouseover="delayShow(this, showmyrepeats)">����</a>
<span class="pipe">|</span><a href="javascript:;" id="myitem" class="showmenu" onmouseover="showMenu({'ctrlid':'myitem'});">�ҵ�</a>
<span class="pipe">|</span><a href="home.php?mod=spacecp">����</a>
<span class="pipe">|</span><a href="home.php?mod=space&amp;do=pm" id="pm_ntc">��Ϣ</a>
<span class="pipe">|</span><a href="home.php?mod=space&amp;do=notice" id="myprompt" class="a showmenu" onmouseover="showMenu({'ctrlid':'myprompt'});">����</a><span id="myprompt_check"></span>
<span class="pipe">|</span><a href="member.php?mod=logging&amp;action=logout&amp;formhash=c045f5dd">�˳�</a>
</p>
<p>
<a href="javascript:;" id="credit" class="showmenu" onmouseover="showMenu({'ctrlid':'credit'});">���ֳ�ֵ</a>
<span class="pipe">|</span>
<a href="home.php?mod=spacecp&amp;ac=credit&amp;showcredit=1" id="extcreditmenu" onmouseover="delayShow(this, showCreditmenu);" class="showmenu">����: 0</a>
<span class="pipe">|</span><a href="home.php?mod=spacecp&amp;ac=usergroup" id="g_upmine" class="showmenu" onmouseover="delayShow(this, showUpgradeinfo)">�û���: �ο�</a>
</p>
</div>
</div>

<div id="nv">
<a href="javascript:;" id="qmenu" onmouseover="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu();})">��ݵ���</a>
<ul><li class="a" id="mn_forum" ><a href="forum.php" hidefocus="true" title="Forum"  >��ҳ<span>Forum</span></a></li><li id="mn_forum_10" ><a href="forum.php?mod=guide" hidefocus="true" title="Guide"  >����<span>Guide</span></a></li><li id="mn_forum_11" ><a href="forum.php?mod=collection" hidefocus="true" title="Collection"  >����<span>Collection</span></a></li><li id="mn_home_4" ><a href="home.php" hidefocus="true" title="Home"  >��԰<span>Home</span></a></li><li id="mn_group" ><a href="group.php" hidefocus="true" title="Group"  >Ȧ��<span>Group</span></a></li><li id="mn_Nfcf7" ><a href="misc.php?mod=tag" hidefocus="true" title="Tag"  >��ǩ<span>Tag</span></a></li><li id="mn_N2d81" ><a href="home.php?mod=task" hidefocus="true" title="Task"  >����<span>Task</span></a></li><li id="mn_N462e" ><a href="plugin.php?id=dsu_paulsign:sign" hidefocus="true" title="Sign"  >ǩ��<span>Sign</span></a></li><li id="mn_N12a7" ><a href="misc.php?mod=ranklist" hidefocus="true" title="Ranklist"  >���а�<span>Ranklist</span></a></li><li><a href="http://www.origamilib.com" title="�̳��鼮��Ʒ��ѯ����" target="_blank">ͼ���ѯ</a></li>
</ul>
</div>
<ul class="p_pop h_pop" id="plugin_menu" style="display: none">  <li><a href="dsu_paulsign-sign.html" id="mn_plink_sign">ÿ��ǩ��</a></li>
 </ul>
<div class="p_pop h_pop" id="mn_userapp_menu" style="display: none"></div><div id="mu" class="cl">
<ul class="cl " id="snav_mn_userapp" style="display:none">
</ul>
</div><div id="scbar" class="scbar_narrow cl">
<form id="scbar_form" method="post" autocomplete="off" onsubmit="searchFocus($('scbar_txt'))" action="search.php?searchsubmit=yes" target="_blank">
<input type="hidden" name="mod" id="scbar_mod" value="search" />
<input type="hidden" name="formhash" value="88f3ec28" />
<input type="hidden" name="srchtype" value="title" />
<input type="hidden" name="srhfid" value="" />
<input type="hidden" name="srhlocality" value="forum::attachment" />
<table cellspacing="0" cellpadding="0">
<tr>
<td class="scbar_icon_td"></td>
<td class="scbar_txt_td"><input type="text" name="srchtxt" id="scbar_txt" value="��������������" autocomplete="off" x-webkit-speech speech /></td>
<td class="scbar_type_td"><a href="javascript:;" id="scbar_type" class="xg1" onclick="showMenu(this.id)" hidefocus="true">����</a></td>
<td class="scbar_btn_td"><button type="submit" name="searchsubmit" id="scbar_btn" sc="1" class="pn pnc" value="true"><strong class="xi2">����</strong></button></td>
<td class="scbar_hot_td">
<div id="scbar_hot">
<strong class="xw1">����: </strong>

<a href="search.php?mod=forum&amp;srchtxt=%D2%C2%B7%FE&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">�·�</a>



<a href="search.php?mod=forum&amp;srchtxt=%D6%BD%B1%D2&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ֽ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%B5%B0%B8%E2&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">����</a>



<a href="search.php?mod=forum&amp;srchtxt=%B1%CA%CD%B2&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">��Ͳ</a>



<a href="search.php?mod=forum&amp;srchtxt=%BD%F0%C7%AE%B9%EA&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">��Ǯ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%BB%A8%C6%BF&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">��ƿ</a>



<a href="search.php?mod=forum&amp;srchtxt=%B7%C9%BB%FA&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">�ɻ�</a>



<a href="search.php?mod=forum&amp;srchtxt=%C8%CB%C3%F1%B1%D2&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">�����</a>



<a href="search.php?mod=forum&amp;srchtxt=%D6%BD%BA%D0&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ֽ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%C3%B1%D7%D3&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ñ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%BC%AA%CB%FB&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">����</a>



<a href="search.php?mod=forum&amp;srchtxt=%C9%BD%D1%F2&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ɽ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%CA%D6&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">��</a>



<a href="search.php?mod=forum&amp;srchtxt=%D5%FB%D0%CE&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">����</a>



<a href="search.php?mod=forum&amp;srchtxt=%C8%B9%D7%D3&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ȹ��</a>



<a href="search.php?mod=forum&amp;srchtxt=%D6%BD%B1%D2%D3%A4%B6%F9%B3%B5&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ֽ��Ӥ����</a>



<a href="search.php?mod=forum&amp;srchtxt=%D6%BD%BA%D0%D6%C6%D7%F7&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">ֽ������</a>



<a href="search.php?mod=forum&amp;srchtxt=%C1%FA%CD%B7&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">��ͷ</a>



<a href="search.php?mod=forum&amp;srchtxt=%D0%AB%D7%D3&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">Ы��</a>



<a href="search.php?mod=forum&amp;srchtxt=%D0%A1%B0%AB%C8%CB&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">С����</a>



<a href="search.php?mod=forum&amp;srchtxt=%D4%BD%C4%CF%D3%A5&amp;formhash=88f3ec28&amp;searchsubmit=true&amp;source=hotsearch" target="_blank" class="xi2" sc="1">Խ��ӥ</a>

</div>
</td>
</tr>
</table>
</form>
</div>
<ul id="scbar_type_menu" class="p_pop" style="display: none;"><li><a href="javascript:;" rel="forum" class="curtype">����</a></li><li><a href="javascript:;" rel="blog">��־</a></li><li><a href="javascript:;" rel="album">���</a></li><li><a href="javascript:;" rel="group">Ȧ��</a></li><li><a href="javascript:;" rel="user">�û�</a></li></ul>
<script type="text/javascript">
initSearchmenu('scbar', '');
</script>
</div>
</div>


<div id="wp" class="wp">
<div id="ct" class="wp cl w">
<div class="nfl">
<div class="f_c altw">
<div id="messagetext" class="alert_error">
<p>��Ǹ������δ��¼��û��Ȩ�����ر�����</p>
<script type="text/javascript">
if(history.length > (BROWSER.ie ? 0 : 1)) {
document.write('<p class="alert_btnleft"><a href="javascript:history.back()">[ ������ﷵ����һҳ ]</a></p>');
} else {
document.write('<p class="alert_btnleft"><a href="./">[ ��ֽѧԺ ��ҳ ]</a></p>');
}
</script>
</div>
</div>
</div>
</div>	</div>
<div id="ft" class="wp cl">
<div id="flk" style="text-align: center">
<p><a href="forum.php?mod=viewthread&tid=178949" title="��ֽ��ѧ֣������" >��վ����</a><span class="pipe">|</span><a href="javascript:;"  onclick="showWindow('miscreport', 'misc.php?mod=report&url='+REPORTURL);return false;">�ٱ�</a><span class="pipe">|</span><a href="forum.php?mod=misc&action=showdarkroom" >С����</a><span class="pipe">|</span><a href="forum.php?mobile=yes" >�ֻ���</a><span class="pipe">|</span><a href="archiver/" >Archiver</a><span class="pipe">|</span><strong><a href="https://www.zhezhixueyuan.com/" target="_blank">��ֽѧԺ</a></strong>
( <a href="https://beian.miit.gov.cn/" target="_blank">³ICP��2021033377��-6</a> )&nbsp;&nbsp;<a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=37032302000141"><img src="./static/image/common/gongan.png" style="margin: -3px 2px 0 0;"> 37032302000141</a>&nbsp;

<a target="_blank" href="https://qm.qq.com/cgi-bin/qm/qr?k=bsjB6cxeMSqhGSsjpGfKoXPExXeIlofo&jump_from=webapi"><img border="0" src="template/mystyle/images/qq_group.png" alt="QQ" title="QQ"></a>

<a href="//wpa.qq.com/msgrd?v=3&amp;uin=1403709207&amp;site=��ֽѧԺ&amp;menu=yes&amp;from=discuz" target="_blank" title="QQ�ͷ�"><img src="template/mystyle/images/qq_customer.png" alt="QQ�ͷ�" /></a></p>
<p class="xs0">
GMT+8, 2026-5-16 22:55<span id="debuginfo">
, Processed in 0.040772 second(s), 8 queries
, MemCached On.
</span>
</p>
</div>
<div id="frt" style="text-align: center">
<p>Powered by <strong><a href="http://www.discuz.net" target="_blank">Discuz!</a></strong> <em>X3.4</em></p>
<p class="xs0">Copyright &copy; 2001-2021, Tencent Cloud.</p>
</div><script type="text/javascript">
var invisiblestatus = '����';
var loginstatusobj = $('loginstatusid');
if(loginstatusobj != undefined && loginstatusobj != null) loginstatusobj.innerHTML = invisiblestatus;
</script>
</div>
<script src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=1778943331" type="text/javascript"></script>
<script src="home.php?mod=spacecp&ac=follow&op=checkfeed&rand=1778943331" type="text/javascript"></script>
<script src="home.php?mod=misc&ac=sendmail&rand=1778943331" type="text/javascript"></script>

<div id="scrolltop">
<span hidefocus="true"><a title="���ض���" onclick="window.scrollTo('0','0')" class="scrolltopa" ><b>���ض���</b></a></span>
</div>
<script type="text/javascript">_attachEvent(window, 'scroll', function () { showTopLink(); });checkBlind();</script>
</body>
</html>
